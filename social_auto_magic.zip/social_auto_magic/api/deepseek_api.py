import requests

class AIContentGenerator:
    def __init__(self, api_key):
        self.api_key = api_key

    def generate_blog_post(self, topic):
        prompt = f"""Create a detailed blog post about {topic} structured for 5 Instagram carousel slides:
        1. Title slide with hook
        2. Key statistic
        3. Process breakdown
        4. Case study
        5. Call-to-action"""
        
        response = requests.post(
            "https://api.deepseek.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {self.api_key}"},
            json={"model": "deepseek-chat", "messages": [{"role": "user", "content": prompt}]}
        )
        return response.json()["choices"][0]["message"]["content"]
import requests

class AIImageGenerator:
    def __init__(self, api_key):
        self.api_key = api_key
    
    def generate_image(self, prompt, output_path):
        response = requests.post(
            "https://api.stability.ai/v2beta/stable-image/generate/sd3",
            headers={"Authorization": f"Bearer {self.api_key}"},
            files={"none": ''},
            data={
                "prompt": f"{prompt}, minimalist digital art, React component style",
                "output_format": "png"
            }
        )
        with open(output_path, 'wb') as f:
            f.write(response.content)
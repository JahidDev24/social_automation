from instagrapi import Client
from core.content_generator import ContentGenerator

class InstagramBot:
    def __init__(self, username, password, deepseek_api_key):
        self.client = Client()
        self.client.login(username, password)
        self.content_gen = ContentGenerator(deepseek_api_key)
    
    def upload_post(self, image_path, caption):
        self.client.photo_upload(image_path, caption)
    
    def upload_reel(self, video_path, caption):
        self.client.clip_upload(video_path, caption)

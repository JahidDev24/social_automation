from platforms.instagram import InstagramBot

def main():
    insta_bot = InstagramBot("developer.jahidkhan@gmail.com", "Wipro@123", "sk-87a88c8d683d44e69bf4732913845c0f")
    topic = input("Enter topic: ")
    caption = insta_bot.content_gen.generate_blog_post(topic)
    hashtags = insta_bot.content_gen.generate_hashtags(topic)
    insta_bot.upload_post("ai_image.png", f"{caption}\n\n{hashtags}")

if __name__ == "__main__":
    main()

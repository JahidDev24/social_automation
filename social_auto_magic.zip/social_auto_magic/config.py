import os
from cryptography.fernet import Fernet
from dotenv import load_dotenv
import warnings

# 1. Load environment
load_dotenv()

# 2. Encryption Key Setup (Generate once and store securely)
# Run this once to generate a key: 
# ```python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())" ```
ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY")  
if not ENCRYPTION_KEY:
    warnings.warn("Missing encryption key. Create one and add to .env as ENCRYPTION_KEY")
    cipher = None
else:
    cipher = Fernet(ENCRYPTION_KEY.encode())

class SecureConfig:
    @staticmethod
    def get(key, decrypt=False):
        val = os.getenv(key)
        if not val:
            raise ValueError(f"Missing environment variable: {key}")
        
        if decrypt and cipher:
            return cipher.decrypt(val.encode()).decode()
        return val

    @staticmethod
    def encrypt(plaintext):
        if not cipher:
            raise RuntimeError("Encryption not initialized")
        return cipher.encrypt(plaintext.encode()).decode()
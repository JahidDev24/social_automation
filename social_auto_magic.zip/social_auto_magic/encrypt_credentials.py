from config import SecureConfig

def setup_credentials():
    password = input("Enter Instagram password: ")
    encrypted = SecureConfig.encrypt(password)
    print(f"\nAdd this to your .env file:\nINSTAGRAM_PASSWORD='{encrypted}'")

if __name__ == "__main__":
    setup_credentials()
def split_to_slides(full_text):
    """Split AI-generated content into 5 slides"""
    slides = []
    current_slide = []
    
    for line in full_text.split('\n'):
        if line.strip() == "":
            if current_slide:
                slides.append("\n".join(current_slide))
                current_slide = []
        else:
            current_slide.append(line)
    
    return slides[:5]  # Ensure exactly 5 slides
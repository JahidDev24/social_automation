from PIL import Image, ImageDraw, ImageFont
import textwrap
import random

class SlideGenerator:
    def __init__(self):
        self.slide_templates = [
            {"bg_color": "#2E86AB", "text_color": "white", "style": "title"},
            {"bg_color": "#F18F01", "text_color": "black", "style": "stat"},
            {"bg_color": "#A63A50", "text_color": "white", "style": "process"},
            {"bg_color": "#3B1F2B", "text_color": "gold", "style": "case_study"},
            {"bg_color": "#6B8F71", "text_color": "white", "style": "cta"}
        ]
    
    def generate_slide(self, text, slide_num, output_path):
        template = self.slide_templates[slide_num % 5]
        
        # Create base image
        img = Image.new("RGB", (1080, 1080), template["bg_color"])
        draw = ImageDraw.Draw(img)
        
        # Add decorative elements (React-style)
        if template["style"] == "title":
            self._add_geometric_pattern(draw)
        
        # Format text
        wrapped_text = textwrap.fill(text, width=30)
        font = ImageFont.truetype("arial.ttf", 42)
        
        # Position text
        bbox = draw.textbbox((0, 0), wrapped_text, font=font)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
        x = (1080 - text_width) / 2
        y = (1080 - text_height) / 2
        
        draw.text((x, y), wrapped_text, fill=template["text_color"], font=font)
        img.save(output_path)
    
    def _add_geometric_pattern(self, draw):
        """Add React-inspired design elements"""
        for _ in range(15):
            x, y = random.randint(0, 1080), random.randint(0, 1080)
            r = random.randint(10, 100)
            draw.ellipse([x-r, y-r, x+r, y+r], outline="white", width=3)
            
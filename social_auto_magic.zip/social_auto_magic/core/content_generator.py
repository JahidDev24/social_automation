import feedparser
from api.deepseek_api import DeepSeekAPI

class ContentGenerator:
    def __init__(self, deepseek_api_key):
        self.deepseek = DeepSeekAPI(deepseek_api_key)
    
    def generate_blog_post(self, topic):
        prompt = f"Write a 200-word Instagram post about {topic}."
        return self.deepseek.generate_text(prompt)
    
    def fetch_rss_feed(self, url, limit=5):
        feed = feedparser.parse(url)
        return [f"{entry.title}\n{entry.description}" for entry in feed.entries[:limit]]
    
    def generate_hashtags(self, topic):
        prompt = f"Generate 10 Instagram hashtags for: {topic}"
        return self.deepseek.generate_text(prompt)
